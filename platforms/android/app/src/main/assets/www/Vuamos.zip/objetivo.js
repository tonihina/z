function cambioFoto() {
          document.getElementById('caja').value=val; 
          var muestra= document.getElementById("next");
          muestra.style.visibility="visible";
}